<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>

        <!-- Fonts -->
        <link href="https://fonts.googleapis.com/css2?family=Nunito:wght@400;600;700&display=swap" rel="stylesheet">

        <!-- Styles -->
        <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-Zenh87qX5JnK2Jl0vWa8Ck2rdkQ2Bzep5IDxbcnCeuOxjzrPF/et3URy9Bv1WTRi" crossorigin="anonymous">
        <link rel="stylesheet" href="{{asset('styling.css')}}">
    </head> 
    <body class="antialiased">
        <div class="h-100">
            @if (Route::has('login'))
                <div class="bg-dark py-3 w-100 d-flex justify-content-end">
                    @auth
                        <a href="{{ url('/home') }}" class="text-warning text-decoration-none me-3"><img src="{{ Auth::user()->avatar }}" style="widows: 20px; height: 20px">{{ Auth::user()->name }} </a>
                    @else
                        <a href="{{ route('login') }}" class="text-decoration-none btn btn-warning me-3">Log in</a>

                        @if (Route::has('register'))
                            <a href="{{ route('register') }}" class="btn btn-outline-warning ext-decoration-none me-3">Register</a>
                        @endif
                    @endauth
                </div>
            @endif 
            <div class="hm bg-dark text-light d-flex justify-content-center flex-column align-items-center text-center">
                <h1 class="fw-bold text-warning mb-3">Authentication</h1>
                <p class="fw-bold">Regist | Login | Logout</p>
                <p class="w-75">Proces to verifying the user identity, in the apps it will verify the user's 
                    account based on the email and password that have registered on our website, authentication 
                    are importants in the website to divide role of each users, and also to prevent user access other
                    users data in the website</p>
            </div>
            <footer class="bg-dark w-100 text-center border border-start-0 border-end-0 border-bottom-dark">
                <h3 class="pt-3 fw-bold text-warning">Simple Authentication</h3>
                <p class="text-light">Created by Rico Susanto</p>
            </footer>
        </div>
    </body>
</html>
