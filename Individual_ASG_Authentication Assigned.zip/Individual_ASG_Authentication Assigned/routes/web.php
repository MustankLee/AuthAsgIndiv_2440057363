<?php

use App\Http\Controllers\GithubController;
use App\Http\Controllers\GoogleController;
use App\Models\User;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Route;
use Laravel\Socialite\Facades\Socialite;


/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/home', [App\Http\Controllers\HomeController::class, 'index'])->name('home');
 

//google
Route::get('login/google', [GoogleController::class, 'redirect_google'])->name('GoogleLogin');
 
Route::get('login/google/callback', function () {
    $user = Socialite::driver('google')->user();
    $check = User::where('email', '=', $user->email)->first();
    if($check == false) {
        $check = new User();
        $check->name = $user->name;
        $check->email = $user->email;
        $check->provider_id = $user->id;
        $check->avatar = $user->avatar;
        $check->save();
    }
    Auth::login($check);
    return view('home');
});

//github
Route::get('login/github', [GithubController::class, 'redirect_github'])->name('GithubLogin');
 
Route::get('login/github/callback', function () {
    $user = Socialite::driver('github')->user();
    $check = User::where('email', '=', $user->email)->first();
    if($check == false) {
        $check = new User();
        $check->name = $user->name;
        $check->email = $user->email;
        $check->provider_id = $user->id;
        $check->avatar = $user->avatar;
        $check->save();
    }
    Auth::login($check);
    return view('home');
});
