<?php echo e($slot); ?>

<?php /**PATH C:\BINUS5\WEB_PROG\LEC\Authentication_Project_Individual\Individual_ASG_Authentication\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/subcopy.blade.php ENDPATH**/ ?>