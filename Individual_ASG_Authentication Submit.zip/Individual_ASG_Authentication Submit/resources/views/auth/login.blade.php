@extends('layouts.app')

@section('content')
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                
                <div class="card-body bg-warning w-100 d-flex justify-content-center">
                    <form  class="bg-warning w-75" method="POST" action="{{ route('login') }}">
                        <h3 class="text-warning fw-bold text-dark text-center mb-4">Login</h3>
                        @csrf
                        <div class="py-3">
                            <label for="email" class="fw-bold">{{ __('Email Address') }}</label>

                            <div class="">
                                <input id="email" type="email" class="form-control @error('email') is-invalid @enderror" name="email" value="{{ old('email') }}" required autocomplete="email" autofocus>

                                @error('email')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror
                            </div>
                        </div>

                        <div class="py-3">
                            <label for="password" class="fw-bold">{{ __('Password') }}</label>

                            <div class="">
                                <input id="password" type="password" class="form-control @error('password') is-invalid @enderror" name="password" required autocomplete="current-password">

                                @error('password')
                                    <span class="invalid-feedback" role="alert">
                                        <strong>{{ $message }}</strong>
                                    </span>
                                @enderror

                            </div>
                        </div>

                        <div class="d-flex align-items-center justify-content-between">
                            <div class="">
                                <input class="form-check-input" type="checkbox" name="remember" id="remember" {{ old('remember') ? 'checked' : '' }}>
                                <label class="form-check-label" for="remember">
                                    {{ __('Remember Me') }}
                                </label>
                            </div>
                            <div class="">
                                @if (Route::has('password.request'))
                                    <a class="text-primary btn btn-link text-decoration-none" href="{{ route('password.request') }}">
                                        {{ __('Forgot Your Password?') }}
                                    </a>
                                @endif
                            </div>
                        </div>
                        
                        <br>
                        <div class="fw-bold text-center">Or</div>
                        <br>

                        <div>
                            <div class="">
                                <div class="py-2">
                                    <a href="{{route('GoogleLogin')}}" class="fw-bold p-3 w-100 btn rounded btn-danger">Login With Google</a>
                                </div>
                                <div class="py-2">
                                    <a href="{{route('GithubLogin')}}" class="fw-bold p-3 w-100 btn btn-dark">Login With Github</a>
                                </div>
                            </div>
                            <div class="w-100 d-flex justify-content-end mt-5">
                                <button type="submit" class="p-2 w-25 btn btn-success">
                                    {{ __('Login') }}
                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
